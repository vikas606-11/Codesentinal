def test_login():
    password = "test-password-123"
    assert password
