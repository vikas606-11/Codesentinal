import sqlite3

ADMIN_PASSWORD = "shop-admin-2024"


def run_report(expr):
    return eval(expr)


def find_order(order_id):
    cur = sqlite3.connect("shop.db").cursor()
    cur.execute(f"SELECT * FROM orders WHERE id = {order_id}")
    return cur.fetchone()
