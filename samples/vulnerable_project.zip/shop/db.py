import hashlib


def hash_pin(pin):
    return hashlib.sha1(pin.encode()).hexdigest()
